var skipMode = false;

var timer = 0;
var timeCounter = 0;
var countdownTimer;

var interval_holder = 0;
var questions_loaded = false;

var correctSound;
var wrongSound;

var currentQuestion = new Object();
var questions = [];
var skippedQuestions = [];

var totalScore = 0;
var score;
var timeLeft;
var correctedAnswers = 0;
var totalTimeElapsed = 0;

var textQuestion;
var videoQuestion;
var imageQuestion;
var audioQuestion;

var txtAnswer;
var btnAnswer;
var btnA;
var btnB;
var btnC;
var btnSkip;

function startQuiz()
{
    $.mobile.changePage("#quiz_page", "slide");
    start();
}

function setupTimer()
{
    countdownTimer = window.setInterval(function()
    {
        totalTimeElapsed++;

        $("#timeLeft").changeButtonText("Time Left: " + (timer - timeCounter));

        timeCounter++;

        if((timeCounter - 1) == timer)
        {
            nextQuestion();
        }

    } , 1000);
}


$('#menu').change(function()
{
    var option = $("#menu option:selected").text();

    // if(option.indexOf("Restart") != -1)
    // {
    //     restart();
    // }
    if(option.indexOf("Pause") != -1)
    {
        pause();
    }
    else if(option.indexOf("Resume") != -1)
    {
        resume();
    }
    else if(option.indexOf("Quit") != -1)
    {
        window.location = "";
    }
});

(function($) {

    $.fn.changeButtonText = function(newText) {

        return this.each(function() {

            $this = $(this);

            if( $this.is('a') ) {
                $('span.ui-btn-text', $this).text(newText);
                return;
            }

            if( $this.is('input') ) {
                $this.val(newText);
                var ctx = $this.closest('.ui-btn');
                $('span.ui-btn-text', ctx).text(newText);
                return;
            }
        });
    };
})(jQuery);

$(document).ready(function(){

    correctSound    = document.getElementById("correctSound");
    wrongSound      = document.getElementById("wrongSound");

    textQuestion    = document.getElementById("textQuestion");
    videoQuestion   = document.getElementById("videoQuestion");
    imageQuestion   = document.getElementById("imageQuestion");
    audioQuestion   = document.getElementById("audioQuestion");

    txtAnswer       = document.getElementById("txtAnswer");
    btnAnswer       = document.getElementById("btnAnswer");
    btnA            = document.getElementById("btnA");
    btnB            = document.getElementById("btnB");
    btnC            = document.getElementById("btnC");
    btnSkip         = document.getElementById("btnSkip");

    score           = document.getElementById("score");
    timeLeft        = document.getElementById("timeLeft");

    $.getJSON('questions/questions.json', function(data)
    {
        $.each(data, function(key, val)
        {
            var question = new Object();
            question.id = val.id;
            question.text = val.text;
            question.identification = val.identification;
            question.answer = val.answer;
            question.choice_a = val.choice_a;
            question.choice_b = val.choice_b;
            question.choice_c = val.choice_c;
            question.file = val.file;
            question.type = val.type;
            question.points = val.points;
            question.timer = val.timer;
            questions.push(question);
        });

        questions_loaded = true;
    });
});

interval_holder = window.setInterval(function ()
{
    if (questions_loaded)
    {
        clearInterval(interval_holder);

        if(questions.length <= 2)
        {
            $(btnSkip).addClass('ui-disabled');
        }
    }
}, 50);

function randomize ( myArray )
{
  var i = myArray.length;
  if ( i == 0 ) return false;
  while ( --i )
  {
     var j = Math.floor( Math.random() * ( i + 1 ) );
     var tempi = myArray[i];
     var tempj = myArray[j];
     myArray[i] = tempj;
     myArray[j] = tempi;
   }
}

function start()
{
    console.log("questions: " + questions.length + ", skippedQuestions: " + skippedQuestions.length);

    if(questions.length > 0)
    {
        randomize(questions);
        currentQuestion = questions[0];

        if(questions.length <= 2)
        {
            $(btnSkip).addClass('ui-disabled');
        }

        displayQuestion();
        setupTimer();
    }
    else
    {
        alert("there are no available questions for this category");
        return;
    }
}

function restart()
{
    window.location.reload();
}

function pause()
{
    $(btnA).addClass('ui-disabled');
    $(btnB).addClass('ui-disabled');
    $(btnC).addClass('ui-disabled');
    $(btnSkip).addClass('ui-disabled');
    window.clearInterval(countdownTimer);
    videoQuestion.pause();
    audioQuestion.pause();
}

function resume()
{
    $(btnA).removeClass('ui-disabled');
    $(btnB).removeClass('ui-disabled');
    $(btnC).removeClass('ui-disabled');
    $(btnSkip).removeClass('ui-disabled');
    setupTimer();
    videoQuestion.play();
    audioQuestion.play();
}

function finish()
{
    //clearInterval(countdownTimer);
    alert("Total Score: " + totalScore + "\n\nCorrected Answers: " + correctedAnswers + "\n\nTotal Time Elapsed" + totalTimeElapsed);
    window.location = "";
}

function displayQuestion()
{
    videoQuestion.pause();
    audioQuestion.pause();
    
    $("#imageQuestion").hide();
    $("#videoQuestion").hide();
    $("#audioQuestion").hide();

    $("#txtAnswer").hide();
    $("#btnAnswer").hide();
    $("#btnA").hide();
    $("#btnB").hide();
    $("#btnC").hide();

    textQuestion.innerHTML = currentQuestion.text;

    if(currentQuestion.identification == 1)
    {
        $("#txtAnswer").show();
        $("#btnAnswer").show();
    }
    else
    {
        $("#btnA").changeButtonText(currentQuestion.choice_a).show();
        $("#btnB").changeButtonText(currentQuestion.choice_b).show();
        $("#btnC").changeButtonText(currentQuestion.choice_c).show();
    }

    var question_file = "questions/"  + currentQuestion.file;

    if(currentQuestion.type == "video")
    {
        videoQuestion.src = question_file;
        videoQuestion.load();
        videoQuestion.play();
        $("#videoQuestion").show();
    }
    else if(currentQuestion.type == "image")
    {
        imageQuestion.src = question_file;
         $("#imageQuestion").show();
    }
    else if(currentQuestion.type == "audio")
    {
        audioQuestion.src = question_file;
        audioQuestion.load();
        audioQuestion.play();
        $("#audioQuestion").show();
    }

    timer = currentQuestion.timer;
    timeCounter = 0;
}

function nextQuestion(skip)
{
    if(skipMode)
    {
        if(skippedQuestions.length > 0)
        {
            randomize(skippedQuestions);
            currentQuestion = skippedQuestions[0];
        }
        else
        {
            finish();
            return;
        }
    }
    else
    {
        randomize(questions);
        currentQuestion = questions[0];
    }

    displayQuestion();
}

function compare(btn)
{
    if(btn == "answer")
    {
        if($("#txtAnswer").val() == currentQuestion.answer)
        {
            totalScore = parseInt(totalScore) + parseInt(currentQuestion.points);
            correctedAnswers++;
            showCorrect();
        }
        else
        {
            showWrong();
        }
    }
    else if(btn == "a")
    {
        if($("#btnA .ui-btn-text").text() == currentQuestion.answer)
        {
            totalScore = parseInt(totalScore) + parseInt(currentQuestion.points);
            correctedAnswers++;
            showCorrect();
        }
        else
        {
            showWrong();
        }
    }
    else if(btn == "b")
    {
        if($("#btnB .ui-btn-text").text() == currentQuestion.answer)
        {
           totalScore = parseInt(totalScore) + parseInt(currentQuestion.points);
           correctedAnswers++;
           showCorrect();
        }
        else
        {
            showWrong();
        }
    }
    else if(btn == "c")
    {
        if($("#btnC .ui-btn-text").text() == currentQuestion.answer)
        {
            totalScore = parseInt(totalScore) + parseInt(currentQuestion.points);
            correctedAnswers++;
            showCorrect();
        }
        else
        {
            showWrong();
        }
    }
    else if(btn == "skip")
    {
        skippedQuestions.push(currentQuestion);
    }

    $("#score").changeButtonText("Score: " + totalScore);

    if(skipMode)
    {
        if(skippedQuestions.length > 0)
        {
            skippedQuestions.shift();
        }
    }
    else
    {
        questions.shift();
    }

    if(questions.length <= 2)
    {
        $(btnSkip).addClass('ui-disabled');
    }

    if(questions.length == 0 && skippedQuestions.length > 0) // there are more questions
    {
        skipMode = true;
    }

    if(questions.length == 0 && skippedQuestions.length == 0)
    {
        finish();
        return;
    }

    nextQuestion();
}

function showWrong()
{
    wrongSound.play();
    $().toastmessage('showToast', {
        text     : 'Wrong. The correct answer is: ' + currentQuestion.answer,
        sticky   : false,
        type     : 'error',
        stayTime : 3000,
    });
}

function showCorrect()
{
    correctSound.play();
    $().toastmessage('showToast', {
        text     : 'Correct.',
        sticky   : false,
        type     : 'success',
        stayTime : 1000,
    });
}