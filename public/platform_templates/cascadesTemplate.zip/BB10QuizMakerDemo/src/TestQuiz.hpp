// Default empty project template
#ifndef TestQuiz_HPP_
#define TestQuiz_HPP_

#include <QtCore/QFile>
#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QVariant>
#include <string>
#include <bb/cascades/AbstractPane>
#include <bb/multimedia/MediaPlayer>
#include <bb/system/SystemToast>
#include <Qt/qobjectdefs.h>
#include <QtCore/QtCore>
#include <stdlib.h>
#include <bb/system/SystemUiResult>

using bb::cascades::AbstractPane;
using bb::multimedia::MediaPlayer;
using bb::system::SystemToast;

namespace bb
{
namespace cascades
{
class Application;
}
}

/*!
 * @brief Application pane object
 *
 *Use this object to create and init app UI, to create context objects, to register the new meta types etc.
 */
class TestQuiz: public QObject
{
Q_OBJECT
public:
	QVariantList questions;
	QVariantList questionsCopy;
	int currentIndex;
	int score;
	MediaPlayer mp;
	MediaPlayer mpCorrect;
	MediaPlayer mpWrong;
	SystemToast *toast;

	AbstractPane *root;
	QTimer *timer;
	QTimer *timer2;

	int timerCounter;

	TestQuiz(bb::cascades::Application *app);
	virtual ~TestQuiz()
	{
	}

public Q_SLOTS:
	void showDialog(QString title, QString body);
	void restart();
	int irand(int min, int max);
	void start();
	void display();
	void next();
	void nextQuestion();
	void displayTimer();
	void compare(QString answer);

signals:
	void onTimeOut();
	void intervalChanged();
	void activeChanged();
};

#endif /* TestQuiz_HPP_ */
