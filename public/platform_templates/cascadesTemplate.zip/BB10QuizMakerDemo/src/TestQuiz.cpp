// Default empty project template
#include "TestQuiz.hpp"

#include <bb/cascades/Application>
#include <bb/cascades/QmlDocument>
#include <bb/cascades/AbstractPane>
#include <bb/cascades/Page>
#include <bb/cascades/ListView>
#include <bb/cascades/databinding/groupdatamodel.h>
#include <qt4/QtCore/QVariant>
#include <bb/data/JsonDataAccess>
#include <bb/cascades/resources/image.h>
#include <bb/cascades/Dialog>
#include <bb/system/SystemDialog>
#include <bb/system/SystemListDialog>
#include <bb/system/SystemPrompt>
#include <bb/system/SystemCredentialsPrompt>
#include <bb/system/SystemToast>
#include <bb/system/SystemUiButton>
#include <bb/system/SystemUiInputField>
#include <bb/system/SystemUiError>
#include <bb/system/SystemUiInputMode>
#include <bb/system/SystemUiModality>
#include <bb/system/SystemUiPosition>
#include <bb/system/SystemUiResult>
#include <bb/multimedia/MediaPlayer>
#include "bps/mediacommon.h"
#include <bb/system/SystemUiPosition>
#include <bb/multimedia/RepeatMode>

#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace bb::cascades;
using bb::data::JsonDataAccess;
using bb::system::SystemDialog;
using namespace bb::system;
using bb::multimedia::RepeatMode;

TestQuiz::TestQuiz(bb::cascades::Application *app) :
		QObject(app)
{
	QmlDocument *qml = QmlDocument::create("asset:///main.qml").parent(this);
	qml->setContextProperty("_app", this);
	root = qml->createRootObject<AbstractPane>();

	JsonDataAccess jda;
	questions =
			jda.load(
					QDir::currentPath()
							+ "/app/native/assets/questions/questions.json").toList();
	questionsCopy = questions;

	score = 0;
	srand(time(0));
	currentIndex = irand(0, questions.length() - 1);

	timerCounter = 0;

	timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(nextQuestion()));

	timer2 = new QTimer(this);
	connect(timer2, SIGNAL(timeout()), this, SLOT(displayTimer()));

	mpCorrect.setSourceUrl(QString("asset:///sounds/correct.wav"));
	mpWrong.setSourceUrl(QString("asset:///sounds/wrong.wav"));

	toast = new SystemToast(this);
	toast->setBody("This is a demo of BB10 Quiz Maker in http://quizmaker.nemoryoliver.com");
	toast->setPosition(SystemUiPosition::TopCenter);
	toast->show();

	start();
	app->setScene(root);
}

void TestQuiz::compare(QString answer)
{
	root->setProperty("headerTimerText", "");

	QString currentCorrectAnswer = questions.at(currentIndex).toMap().value(
			"answer").toString();

	if (answer.toUpper() == currentCorrectAnswer.toUpper())
	{
		mpCorrect.play();

		int points =
				questions.at(currentIndex).toMap().value("points").toString().toInt();
		score += points;

		QVariant tmp(score);
		root->setProperty("headerScoreText", "Score: " + tmp.toString());
	}
	else
	{
		mpWrong.play();
		qDebug() << "Wrong, answer: " << currentCorrectAnswer;
		toast->setBody("Correct Answer: " + currentCorrectAnswer);
		toast->setPosition(SystemUiPosition::TopCenter);
		toast->show();
	}

	next();
}

void TestQuiz::next()
{
	if (questions.length() > 1)
	{
		questions.removeAt(currentIndex);
		srand(time(0));
		currentIndex = irand(0, questions.length() - 1);
		display();
	}
	else
	{
		timer->stop();
		timer2->stop();

		if (mp.mediaState() == bb::multimedia::MediaState::Started)
		{
			mp.stop();
		}

		QVariant tmp(score);
		showDialog(QString("Quiz Finished"), "Total Score:" + tmp.toString() + "\n\nIf you want to play again, swipe from the top and click restart.");
	}
}

void TestQuiz::display()
{
	QVariantMap questionsMap = questions.at(currentIndex).toMap();
	QString identification = questionsMap.value("identification").toString();
	QString questionText = questionsMap.value("text").toString();
	QString questionType = questionsMap.value("type").toString();
	QString btnAtext = questionsMap.value("choice_a").toString();
	QString btnBtext = questionsMap.value("choice_b").toString();
	QString btnCtext = questionsMap.value("choice_c").toString();
	QString file = questionsMap.value("file").toString();

	int seconds = questionsMap.value("timer").toString().toInt();

	timerCounter = seconds;

	timer->setInterval(1000);
	timer->start(seconds * 1000);
	timer2->start(1000);

	root->setProperty("questionImagevisible", false);
	root->setProperty("txtAnswervisible", false);
	root->setProperty("btnAnswervisible", false);
	root->setProperty("btnAvisible", false);
	root->setProperty("btnBvisible", false);
	root->setProperty("btnCvisible", false);

	root->setProperty("questionText", questionText);
	root->setProperty("btnAtext", btnAtext);
	root->setProperty("btnBtext", btnBtext);
	root->setProperty("btnCtext", btnCtext);

	if (mp.mediaState() == bb::multimedia::MediaState::Started)
	{
		mp.stop();
	}

	if (identification == "1")
	{
		root->setProperty("txtAnswervisible", true);
		root->setProperty("btnAnswervisible", true);
	}
	else
	{
		root->setProperty("btnAvisible", true);
		root->setProperty("btnBvisible", true);
		root->setProperty("btnCvisible", true);
	}

	if (questionType == "image")
	{
		root->setProperty("questionImagevisible", true);
		root->setProperty("questionImageSource",
				QString("asset:///questions/" + file));
	}
	else if (questionType == "video")
	{
		next();
	}
	else if (questionType == "audio")
	{
		mp.setSourceUrl(QString("asset:///questions/" + file));
		mp.setRepeatMode(RepeatMode::Track);
		mp.play();
	}
}

void TestQuiz::restart()
{
	score = 0;
	timer->stop();
	timer2->stop();

	if (mp.mediaState() == bb::multimedia::MediaState::Started)
	{
		mp.stop();
	}

	questions.clear();
	questions = questionsCopy;

	root->setProperty("headerTimerText", "");

	srand(time(0));
	currentIndex = irand(0, questions.length() - 1);
	display();
}

void TestQuiz::start()
{
	display();
}

void TestQuiz::nextQuestion()
{
	timer2->stop();
	timer->stop();
	next();
}

void TestQuiz::displayTimer()
{
	timerCounter--;
	QVariant tmp1(timerCounter);
	root->setProperty("headerTimerText", "Timer: " + tmp1.toString());
	QVariant tmp2(score);
	root->setProperty("headerScoreText", "Score: " + tmp2.toString());
}

void TestQuiz::showDialog(QString title, QString body)
{
	SystemDialog *dialog = new SystemDialog("Ok");
	dialog->setTitle(title);
	dialog->setBody(body);
	dialog->show();
}

int TestQuiz::irand(int min, int max)
{
	return ((double) rand() / ((double) RAND_MAX + 1.0)) * (max - min + 1) + min;
}
