/****************************************************************************
** Meta object code from reading C++ file 'app.hpp'
**
** Created: Tue Jan 15 23:19:12 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/app.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'app.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_App[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       5,   64, // properties
       1,   84, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      10,    5,    4,    4, 0x05,
      41,   35,    4,    4, 0x05,
      71,   66,    4,    4, 0x05,
     102,   95,    4,    4, 0x05,
     131,  125,    4,    4, 0x05,

 // slots: signature, parameters, type, tag, flags
     151,    4,    4,    4, 0x0a,
     170,    4,    4,    4, 0x0a,
     188,    4,    4,    4, 0x0a,
     206,    5,    4,    4, 0x0a,
     237,    4,    4,    4, 0x0a,

 // properties: name, type, flags
     272,  264, 0x0a495103,
     281,  264, 0x0a495103,
     290,  264, 0x0a495103,
      95,  264, 0x0a495103,
     125,  298, 0x0049510b,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,

 // enums: name, flags, count, data
     298, 0x0,    4,   88,

 // enum data: key, value
     304, uint(App::Init),
     309, uint(App::JsonLoaded),
     320, uint(App::QtDisplayed),
     332, uint(App::ReadyToWrite),

       0        // eod
};

static const char qt_meta_stringdata_App[] = {
    "App\0\0data\0jsonDataChanged(QString)\0"
    "title\0rhsTitleChanged(QString)\0text\0"
    "rhsTextChanged(QString)\0result\0"
    "resultChanged(QString)\0state\0"
    "stateChanged(State)\0loadOriginalJson()\0"
    "convertJsonToQt()\0convertQtToJson()\0"
    "updateJsonDataFromQml(QString)\0"
    "writeToJsonFileAndReload()\0QString\0"
    "jsonData\0rhsTitle\0rhsText\0State\0Init\0"
    "JsonLoaded\0QtDisplayed\0ReadyToWrite\0"
};

void App::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        App *_t = static_cast<App *>(_o);
        switch (_id) {
        case 0: _t->jsonDataChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->rhsTitleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->rhsTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->resultChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->stateChanged((*reinterpret_cast< State(*)>(_a[1]))); break;
        case 5: _t->loadOriginalJson(); break;
        case 6: _t->convertJsonToQt(); break;
        case 7: _t->convertQtToJson(); break;
        case 8: _t->updateJsonDataFromQml((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->writeToJsonFileAndReload(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData App::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject App::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_App,
      qt_meta_data_App, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &App::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *App::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *App::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_App))
        return static_cast<void*>(const_cast< App*>(this));
    return QObject::qt_metacast(_clname);
}

int App::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = jsonData(); break;
        case 1: *reinterpret_cast< QString*>(_v) = rhsTitle(); break;
        case 2: *reinterpret_cast< QString*>(_v) = rhsText(); break;
        case 3: *reinterpret_cast< QString*>(_v) = result(); break;
        case 4: *reinterpret_cast< State*>(_v) = state(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setJsonData(*reinterpret_cast< QString*>(_v)); break;
        case 1: setRhsTitle(*reinterpret_cast< QString*>(_v)); break;
        case 2: setRhsText(*reinterpret_cast< QString*>(_v)); break;
        case 3: setResult(*reinterpret_cast< QString*>(_v)); break;
        case 4: setState(*reinterpret_cast< State*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void App::jsonDataChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void App::rhsTitleChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void App::rhsTextChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void App::resultChanged(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void App::stateChanged(State _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
