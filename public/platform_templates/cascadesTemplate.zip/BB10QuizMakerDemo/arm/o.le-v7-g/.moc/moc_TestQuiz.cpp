/****************************************************************************
** Meta object code from reading C++ file 'TestQuiz.hpp'
**
** Created: Sat Jan 19 11:41:43 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/TestQuiz.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TestQuiz.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TestQuiz[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x05,
      22,    9,    9,    9, 0x05,
      40,    9,    9,    9, 0x05,

 // slots: signature, parameters, type, tag, flags
      67,   56,    9,    9, 0x0a,
      95,    9,    9,    9, 0x0a,
     117,  109,  105,    9, 0x0a,
     132,    9,    9,    9, 0x0a,
     140,    9,    9,    9, 0x0a,
     150,    9,    9,    9, 0x0a,
     157,    9,    9,    9, 0x0a,
     172,    9,    9,    9, 0x0a,
     194,  187,    9,    9, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_TestQuiz[] = {
    "TestQuiz\0\0onTimeOut()\0intervalChanged()\0"
    "activeChanged()\0title,body\0"
    "showDialog(QString,QString)\0restart()\0"
    "int\0min,max\0irand(int,int)\0start()\0"
    "display()\0next()\0nextQuestion()\0"
    "displayTimer()\0answer\0compare(QString)\0"
};

void TestQuiz::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TestQuiz *_t = static_cast<TestQuiz *>(_o);
        switch (_id) {
        case 0: _t->onTimeOut(); break;
        case 1: _t->intervalChanged(); break;
        case 2: _t->activeChanged(); break;
        case 3: _t->showDialog((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 4: _t->restart(); break;
        case 5: { int _r = _t->irand((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 6: _t->start(); break;
        case 7: _t->display(); break;
        case 8: _t->next(); break;
        case 9: _t->nextQuestion(); break;
        case 10: _t->displayTimer(); break;
        case 11: _t->compare((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TestQuiz::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TestQuiz::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_TestQuiz,
      qt_meta_data_TestQuiz, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TestQuiz::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TestQuiz::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TestQuiz::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TestQuiz))
        return static_cast<void*>(const_cast< TestQuiz*>(this));
    return QObject::qt_metacast(_clname);
}

int TestQuiz::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void TestQuiz::onTimeOut()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void TestQuiz::intervalChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void TestQuiz::activeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
QT_END_MOC_NAMESPACE
